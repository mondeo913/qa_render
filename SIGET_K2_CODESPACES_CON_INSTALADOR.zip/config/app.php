<?php
return [
 'name'=>env('APP_NAME','SIGET'),
 'env'=>env('APP_ENV','production'),
 'debug'=>(bool)env('APP_DEBUG',false),
 'url'=>env('APP_URL','http://localhost'),
 'timezone'=>env('APP_TIMEZONE','America/Mexico_City'),
 'locale'=>env('APP_LOCALE','es'),
 'fallback_locale'=>env('APP_FALLBACK_LOCALE','es'),
 'faker_locale'=>'es_MX',
 'cipher'=>'AES-256-CBC',
 'key'=>env('APP_KEY'),
 'previous_keys'=>array_filter(explode(',',env('APP_PREVIOUS_KEYS',''))),
 'maintenance'=>['driver'=>'file','store'=>'database'],
];
